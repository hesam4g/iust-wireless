import math
z = 1.29
n = 3.03300685974
sigma = 1.01279900387
d = 2;
while(-31.739-10*n*math.log10(d) - z*sigma > -85):
	d+=0.1
print(d)
#javab = 51.7


